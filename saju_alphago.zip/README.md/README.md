# 사주 알파고 (Saju Alphago)

## 프로젝트 개요
**사주 알파고**는 사용자가 자신의 **생년월일**과 **출생 시간**을 입력하여, AI를 활용한 사주 분석 결과를 제공하는 웹 기반 소프트웨어입니다. 이 프로젝트는 OpenAI GPT API를 사용하여 전통적인 사주 해석을 현대적으로 재구성하고, 사용자에게 더 직관적이고 실용적인 경험을 제공합니다.

---

## 주요 기능
1. **사주 조회**
   - 사용자가 생년월일, 출생 시간, 성별을 입력하면 AI가 사주 분석 결과를 생성.
   - 결과를 성격, 금전운, 연애운 등으로 분류하여 제공.

2. **저장 기능**
   - 조회된 사주 데이터를 JSON 형식으로 저장.
   - 저장된 데이터를 기반으로 결과를 다시 불러오거나 삭제 가능.

3. **오늘의 운세**
   - 생년월일을 기반으로 하루 운세를 생성.
   - 텍스트와 이미지로 결과를 제공하고 SNS 공유 가능.

4. **궁합 분석**
   - 두 사용자의 생년월일과 출생 시간을 입력받아 궁합을 분석.
   - 금전적, 성격적 궁합 등을 차트와 그래프로 표현.

5. **커뮤니티**
   - 사용자 간 소통을 위한 게시판 제공.
   - 게시글 작성, 수정, 삭제, 댓글 기능 지원.

6. **리뷰 및 피드백**
   - 분석 결과에 대한 리뷰와 별점(1~5) 작성.
   - 사용자 피드백을 통해 서비스 개선.

7. **AI 기술 소개**
   - OpenAI GPT API와 DALL-E API를 활용한 분석 및 이미지 생성 방식을 소개.

---

## 폴더 및 파일 구조
```plaintext
C:\saju_alphago\
│
├── index.html               # 메인 페이지
├── saju.html                # 사주 조회 페이지
├── saved_results.html       # 저장 목록 페이지
├── community.html           # 커뮤니티 페이지
├── compatibility.html       # 궁합 분석 페이지
├── daily_fortune.html       # 오늘의 운세 페이지
├── feedback.html            # 리뷰 및 피드백 페이지
├── about.html               # AI 소개 페이지
│
├── assets/                  # 정적 파일 폴더
│   ├── css/                 # 스타일 파일
│   │   └── style.css
│   ├── js/                  # 스크립트 파일
│   │   └── script.js
│   └── images/              # 이미지 파일
│       ├── logo.png
│       ├── main-image.png
│       └── 기타 UI 요소 이미지
│
├── data/                    # 데이터 파일 폴더
│   └── saved-results.json   # 저장된 사주 결과
│
├── api/                     # API 처리 폴더
│   ├── analyze-saju.js      # 사주 분석 API 호출
│   ├── fetch-results.js     # 저장된 결과 불러오기
│   └── 기타 API 처리 파일
│
├── sql/                     # 데이터베이스 설계 파일 폴더
│   └── saju_alphago.sql     # 초기 데이터베이스 설계
│
└── README.md                # 프로젝트 설명 파일


사용 기술
프론트엔드:

HTML, CSS, JavaScript: UI/UX 구성.
Chart.js: 분석 결과를 그래프로 시각화.
백엔드:

Node.js + Express.js: API 호출 및 데이터 처리.
Firebase: 사용자 인증 및 데이터 저장.
API:

OpenAI GPT API: 사주 분석 데이터 생성.
DALL-E API: 분석 결과 이미지 생성.
Twilio API: 사용자 알림 전송.
데이터베이스:

Firebase 실시간 데이터베이스: 사용자 데이터 및 저장된 결과 관리.


향후 개발 계획
SNS 로그인 기능 추가(Google, Kakao 등).
분석 결과에 따른 추천 시스템 고도화.
Twilio API를 활용한 실시간 알림 시스템 추가.

추천 순서
개발 환경 설정: 필수 프로그램과 라이브러리를 설치 및 초기화.
코드 작성 시작: 준비된 환경에서 순서대로 코드를 작성..

1. 개발 환경 설정
필수 프로그램 다운로드 및 설치
Node.js 설치

공식 사이트: https://nodejs.org/
LTS(Long-Term Support) 버전을 설치하세요.
설치 후 확인:
bash
코드 복사
node -v
npm -v
Git 설치

버전 관리와 프로젝트 협업을 위해 필요.
공식 사이트: https://git-scm.com/
설치 후 확인:
bash
코드 복사
git --version
Visual Studio Code 설치

개발을 위한 코드 에디터.
공식 사이트: https://code.visualstudio.com/
Firebase CLI (Command Line Interface) 설치

Firebase를 사용해 인증, 데이터베이스, 호스팅을 설정.
설치 명령어:
bash
코드 복사
npm install -g firebase-tools
설치 후 확인:
bash
코드 복사
firebase --version


saju_alphago/
│
├── public/
│   ├── index.html              # 메인 페이지
│   ├── saju.html               # 사주 조회 페이지
│   ├── saved_results.html      # 저장된 분석 결과 목록
│   ├── daily_fortune.html      # 오늘의 운세 페이지
│   ├── compatibility.html      # 궁합 분석 페이지
│   ├── feedback.html           # 사용자 리뷰 및 피드백
│   ├── about.html              # 사주 알파고 소개 페이지
│   ├── faq.html                # 자주 묻는 질문
│   ├── how_ai_works.html       # AI 작동 방식 설명
│   ├── assets/
│   │   ├── css/style.css       # 공통 스타일
│   │   └── js/script.js        # 공통 스크립트
│   └── data/
│       ├── saju-data.json      # 사주 분석 기본 데이터
│       ├── user-data.json      # 샘플 사용자 데이터
│       ├── saved-results.json  # 저장된 분석 결과
│       ├── daily-fortune.json  # 오늘의 운세 데이터
│       ├── compatibility.json  # 궁합 분석 데이터
│       └── user-stats.json     # 사용자 통계 데이터
│
├── api/
│   ├── analyze-saju.js         # 사주 분석 API
│   ├── compatibility-api.js    # 궁합 분석 API
│   ├── daily-fortune-api.js    # 오늘의 운세 API
│   ├── feedback-api.js         # 피드백 API
│   ├── recommended-api.js      # 추천 결과 API
│   └── social-share.js         # SNS 공유 API
│
├── sql/
│   ├── saju_alphago.sql        # 사용자 및 사주 분석 스키마
│   ├── feedback.sql            # 피드백 스키마
│   ├── compatibility.sql       # 궁합 분석 스키마
│   └── stats.sql               # 사용자 통계 스키마
│
├── config/
│   └── api-keys.json           # API 키 저장
│
├── server.js                   # Express 서버
├── README.md                   # 프로젝트 설명서
└── .gitignore                  # Git 제외 파일
🧩 주요 기술 스택
프론트엔드: HTML, CSS, JavaScript
백엔드: Node.js, Express.js
데이터베이스: MySQL
AI API: OpenAI GPT API
기타: Firebase (사용자 인증)
🌟 완료한 작업
프론트엔드 페이지 개발:
index.html, saju.html, daily_fortune.html, feedback.html 등 주요 페이지 작성.
API 개발:
analyze-saju.js: OpenAI API를 통한 사주 분석.
daily-fortune-api.js: 오늘의 운세 생성.
compatibility-api.js: 궁합 분석 처리.
feedback-api.js: 사용자 피드백 저장.
recommended-api.js: 추천 결과 생성.
social-share.js: SNS 공유 링크 생성.
데이터베이스 스키마 작성:
사용자, 사주 분석 결과, 피드백, 궁합, 통계를 위한 테이블 생성.
📝 추가 작업
데이터베이스 연동 테스트 및 데이터 삽입.
서버 엔드포인트와 프론트엔드 통합.
Firebase를 통한 사용자 인증(선택 사항).

📧 문의
이메일: your-email@example.com
GitHub: Your GitHub Repository
markdown
코드 복사

---

### **README 주요 내용**
- **설치 및 실행 방법**: 프로젝트를 설정하고 실행하는 단계.
- **프로젝트 구조**: 디렉토리와 파일 설명.
- **완료한 작업**: 현재까지 완료된 기능 및 작업.
- **추가 작업**: 앞으로 해야 할 작업.

필요한 추가 내용이 있다면 알려주세요! 😊
