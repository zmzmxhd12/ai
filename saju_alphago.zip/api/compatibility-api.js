const axios = require('axios');
const fs = require('fs');

// OpenAI API 키 로드
const OPENAI_API_KEY = JSON.parse(fs.readFileSync('./config/api-keys.json')).openai_api_key;

/**
 * OpenAI GPT API를 호출하여 궁합 분석 결과를 생성합니다.
 * @param {string} person1Birthday - 첫 번째 사람의 생년월일 (예: "1990-01-01").
 * @param {string} person1BirthTime - 첫 번째 사람의 출생 시간 (예: "10:30").
 * @param {string} person2Birthday - 두 번째 사람의 생년월일 (예: "1995-07-15").
 * @param {string} person2BirthTime - 두 번째 사람의 출생 시간 (예: "14:00").
 * @returns {Promise<string>} - 궁합 분석 결과 텍스트.
 */
async function analyzeCompatibility(person1Birthday, person1BirthTime, person2Birthday, person2BirthTime) {
    try {
        const prompt = `Analyze the compatibility between two individuals based on their Saju information:
        - Person 1:
          - Birthday: ${person1Birthday}
          - Birth Time: ${person1BirthTime}
        - Person 2:
          - Birthday: ${person2Birthday}
          - Birth Time: ${person2BirthTime}
        Provide insights into their relationship compatibility, including emotional, financial, and general aspects.`;

        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo', // gpt-4 사용 가능
                messages: [{ role: 'user', content: prompt }],
                max_tokens: 500,
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        // OpenAI의 응답에서 분석 결과 추출
        return response.data.choices[0].message.content;
    } catch (error) {
        console.error('OpenAI API 호출 중 오류:', error.response?.data || error.message);
        throw new Error('궁합 분석 중 문제가 발생했습니다.');
    }
}

module.exports = analyzeCompatibility;
