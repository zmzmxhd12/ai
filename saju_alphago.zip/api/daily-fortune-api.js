const axios = require('axios');
const fs = require('fs');

// OpenAI API 키 로드
const OPENAI_API_KEY = JSON.parse(fs.readFileSync('./config/api-keys.json')).openai_api_key;

/**
 * OpenAI GPT API를 호출하여 오늘의 운세를 생성합니다.
 * @param {string} birthday - 사용자의 생년월일 (예: "1990-01-01").
 * @param {string} zodiacSign - 사용자의 별자리 (예: "Capricorn").
 * @returns {Promise<object>} - 오늘의 운세 텍스트를 포함한 객체.
 */
async function generateDailyFortune(birthday, zodiacSign) {
    try {
        const prompt = `Create a detailed daily horoscope for the following:
        - Birthday: ${birthday}
        - Zodiac Sign: ${zodiacSign}
        Provide insights into general life, career, love, and health for today.`;

        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo', // gpt-4 사용 가능
                messages: [{ role: 'user', content: prompt }],
                max_tokens: 500,
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const result = response.data.choices[0].message.content;

        // 결과를 JSON 형태로 반환
        return {
            date: new Date().toISOString().split('T')[0],
            zodiacSign,
            birthday,
            fortune: result
        };
    } catch (error) {
        console.error('OpenAI API 호출 중 오류:', error.response?.data || error.message);
        throw new Error('오늘의 운세 생성 중 문제가 발생했습니다.');
    }
}

module.exports = generateDailyFortune;
