const fs = require('fs');
const path = require('path');

/**
 * 피드백 데이터를 저장합니다.
 * @param {object} feedback - 사용자 피드백 객체.
 * @param {number} feedback.userId - 사용자 ID.
 * @param {number} feedback.rating - 별점 (1~5).
 * @param {string} feedback.comment - 피드백 코멘트.
 * @returns {Promise<object>} - 저장된 피드백 데이터.
 */
async function saveFeedback(feedback) {
    const filePath = path.join(__dirname, '../data/feedback.json');

    try {
        // 기존 피드백 데이터를 읽어옵니다.
        const existingFeedback = fs.existsSync(filePath)
            ? JSON.parse(fs.readFileSync(filePath, 'utf-8'))
            : [];

        // 새로운 피드백 추가
        const newFeedback = {
            id: existingFeedback.length + 1, // 고유 ID 생성
            userId: feedback.userId,
            rating: feedback.rating,
            comment: feedback.comment,
            date: new Date().toISOString()
        };

        existingFeedback.push(newFeedback);

        // 데이터를 JSON 파일에 저장
        fs.writeFileSync(filePath, JSON.stringify(existingFeedback, null, 2), 'utf-8');

        return newFeedback;
    } catch (error) {
        console.error('피드백 저장 중 오류:', error.message);
        throw new Error('피드백 저장에 실패했습니다.');
    }
}

/**
 * 저장된 모든 피드백 데이터를 가져옵니다.
 * @returns {Promise<object[]>} - 모든 피드백 데이터 배열.
 */
async function fetchAllFeedback() {
    const filePath = path.join(__dirname, '../data/feedback.json');

    try {
        if (!fs.existsSync(filePath)) {
            return []; // 파일이 없으면 빈 배열 반환
        }

        const data = fs.readFileSync(filePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error('피드백 데이터 불러오기 중 오류:', error.message);
        throw new Error('피드백 데이터를 불러오는 데 실패했습니다.');
    }
}

module.exports = {
    saveFeedback,
    fetchAllFeedback
};
