const fs = require('fs');
const path = require('path');

/**
 * 저장된 결과를 JSON 파일에서 불러옵니다.
 * @returns {Promise<object[]>} - 저장된 결과 배열.
 */
async function fetchSavedResults() {
    const filePath = path.join(__dirname, '../data/saved-results.json');

    try {
        // JSON 파일이 존재하지 않는 경우 빈 배열 반환
        if (!fs.existsSync(filePath)) {
            return [];
        }

        // JSON 파일 읽기
        const data = fs.readFileSync(filePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error('저장된 결과 불러오기 중 오류:', error.message);
        throw new Error('저장된 결과를 불러오는 중 문제가 발생했습니다.');
    }
}

/**
 * 특정 사용자의 저장된 결과를 필터링합니다.
 * @param {number} userId - 특정 사용자 ID.
 * @returns {Promise<object[]>} - 해당 사용자의 저장된 결과 배열.
 */
async function fetchResultsByUser(userId) {
    try {
        const results = await fetchSavedResults();

        // 특정 사용자의 결과만 필터링
        return results.filter(result => result.userId === userId);
    } catch (error) {
        console.error('사용자별 결과 불러오기 중 오류:', error.message);
        throw new Error('사용자별 결과를 불러오는 중 문제가 발생했습니다.');
    }
}

module.exports = {
    fetchSavedResults,
    fetchResultsByUser
};
