const axios = require('axios');
const fs = require('fs');

// OpenAI API 키 로드
const OPENAI_API_KEY = JSON.parse(fs.readFileSync('./config/api-keys.json')).openai_api_key;

/**
 * OpenAI GPT API를 호출하여 추천 결과를 생성합니다.
 * @param {string} analysisResult - 사주 분석 결과 텍스트.
 * @returns {Promise<string>} - 추천 결과 텍스트.
 */
async function generateRecommendations(analysisResult) {
    try {
        const prompt = `Based on the following Saju analysis result:
        "${analysisResult}"
        Provide personalized recommendations for:
        - Financial decisions
        - Career development
        - Relationship advice
        - Health tips.`;

        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo', // gpt-4 사용 가능
                messages: [{ role: 'user', content: prompt }],
                max_tokens: 500,
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        // OpenAI의 응답에서 추천 결과 추출
        return response.data.choices[0].message.content;
    } catch (error) {
        console.error('OpenAI API 호출 중 오류:', error.response?.data || error.message);
        throw new Error('추천 결과 생성 중 문제가 발생했습니다.');
    }
}

module.exports = generateRecommendations;
