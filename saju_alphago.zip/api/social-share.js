/**
 * SNS 공유 링크를 생성합니다.
 * @param {string} platform - SNS 플랫폼 (예: "twitter", "facebook", "kakao").
 * @param {string} content - 공유할 텍스트 내용.
 * @param {string} url - 공유할 페이지 URL.
 * @returns {string} - 플랫폼에 맞는 공유 URL.
 */
function generateSocialShareLink(platform, content, url) {
    const encodedContent = encodeURIComponent(content);
    const encodedUrl = encodeURIComponent(url);

    switch (platform.toLowerCase()) {
        case 'twitter':
            return `https://twitter.com/intent/tweet?text=${encodedContent}&url=${encodedUrl}`;
        case 'facebook':
            return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        case 'kakao':
            // 카카오톡 링크 API 사용
            return `https://sharer.kakao.com/talk/friends/picker/link?link=${encodedUrl}&text=${encodedContent}`;
        case 'linkedin':
            return `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedContent}`;
        default:
            throw new Error(`Unsupported platform: ${platform}`);
    }
}

/**
 * SNS 공유 버튼 HTML을 생성합니다.
 * @param {string[]} platforms - 사용할 SNS 플랫폼 목록 (예: ["twitter", "facebook", "kakao"]).
 * @param {string} content - 공유할 텍스트 내용.
 * @param {string} url - 공유할 페이지 URL.
 * @returns {string} - HTML 코드.
 */
function generateShareButtons(platforms, content, url) {
    const buttons = platforms.map(platform => {
        const shareLink = generateSocialShareLink(platform, content, url);
        return `<a href="${shareLink}" target="_blank" class="social-share-button ${platform}">${platform.toUpperCase()}</a>`;
    });

    return buttons.join(' ');
}

module.exports = {
    generateSocialShareLink,
    generateShareButtons
};
