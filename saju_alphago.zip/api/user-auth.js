const { initializeApp } = require('firebase/app');
const { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } = require('firebase/auth');

// Firebase 초기화 설정
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Firebase 앱 초기화
const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);

/**
 * 사용자 회원가입 처리
 * @param {string} email - 사용자 이메일.
 * @param {string} password - 사용자 비밀번호.
 * @returns {Promise<object>} - 사용자 정보.
 */
async function registerUser(email, password) {
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        return { userId: userCredential.user.uid, email: userCredential.user.email };
    } catch (error) {
        console.error('회원가입 오류:', error.message);
        throw new Error('회원가입에 실패했습니다.');
    }
}

/**
 * 사용자 로그인 처리
 * @param {string} email - 사용자 이메일.
 * @param {string} password - 사용자 비밀번호.
 * @returns {Promise<object>} - 사용자 정보.
 */
async function loginUser(email, password) {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return { userId: userCredential.user.uid, email: userCredential.user.email };
    } catch (error) {
        console.error('로그인 오류:', error.message);
        throw new Error('로그인에 실패했습니다.');
    }
}

/**
 * 사용자 로그아웃 처리
 * @returns {Promise<void>}
 */
async function logoutUser() {
    try {
        await signOut(auth);
        console.log('로그아웃 완료');
    } catch (error) {
        console.error('로그아웃 오류:', error.message);
        throw new Error('로그아웃에 실패했습니다.');
    }
}

module.exports = {
    registerUser,
    loginUser,
    logoutUser
};
