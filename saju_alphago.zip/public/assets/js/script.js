document.getElementById("analyzeButton").addEventListener("click", async (e) => {
    e.preventDefault();

    const birthday = document.getElementById("birthday").value;
    const birthTime = document.getElementById("birthTime").value;
    const gender = document.getElementById("gender").value;
    const location = document.getElementById("location").value;

    try {
        const response = await fetch("/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ birthday, birthTime, gender, location }),
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById("resultSection").innerHTML = `<pre>${data.result}</pre>`;
            document.getElementById("resultSection").style.display = "block";
        } else {
            const error = await response.json();
            alert(error.error || "분석 중 오류가 발생했습니다.");
        }
    } catch (err) {
        alert("서버와 연결하는 데 실패했습니다.");
    }
});
