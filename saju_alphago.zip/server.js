const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

// Load OpenAI API Key
let OPENAI_API_KEY;
try {
    const configPath = path.join(__dirname, "config", "api-keys.json");
    const config = JSON.parse(fs.readFileSync(configPath));
    OPENAI_API_KEY = config.openai_api_key;
    if (!OPENAI_API_KEY) {
        throw new Error("API key is missing.");
    }
} catch (error) {
    console.error("Error loading API key:", error.message);
    process.exit(1);
}

// Serve static files
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.json());

// Endpoint for astrological analysis
app.post("/analyze", async (req, res) => {
    const { birthday, birthTime, gender, location } = req.body;

    if (!birthday || !birthTime || !gender || !location) {
        return res.status(400).json({ error: "생년월일, 출생 시간, 성별, 태어난 장소를 모두 입력해주세요." });
    }

    try {
        const response = await axios.post(
            "https://api.openai.com/v1/chat/completions",
            {
                model: "gpt-4",
                messages: [
                    {
                        role: "system",
                        content: "당신은 동양 점성술 전문가입니다. 모든 답변은 한국어로 작성하며, 명확하고 사용자 친화적으로 표현해주세요. 결과는 깔끔한 섹션으로 나누어 제공하고, 각 섹션은 헤더와 항목을 포함합니다."
                    },
                    {
                        role: "user",
                        content: `아래 정보를 바탕으로 점성술 분석을 제공해주세요:
                        - 생년월일: ${birthday}
                        - 출생 시간: ${birthTime}
                        - 성별: ${gender}
                        - 태어난 장소: ${location}
                        
                        결과에는 다음 내용을 포함하세요:
                        1. 성격 분석: 성격, 강점, 약점.
                        2. 주요 운세: 금전운, 연애운, 건강운.
                        3. 조언: 삶에서 성공을 위한 구체적인 조언.
                        4. 각 분석한 성경,강점,약점,금전운,연애운,건강운, 분석할때 소제목 으로 하세요.
                        5. 마지막 최종 금전,연애,건강 의 점수를 각각 매겨줘.
                        분석 결과는 최소 1000자 이상으로 작성해주세요.`
                    }
                ],
                max_tokens: 8192
            },
            {
                headers: {
                    Authorization: `Bearer ${OPENAI_API_KEY}`,
                    "Content-Type": "application/json"
                }
            }
        );

        const result = response.data.choices[0].message.content;

        res.json({ result });
    } catch (error) {
        console.error("OpenAI API 호출 중 오류:", error.message);
        res.status(500).json({ error: "점성술 분석 중 오류가 발생했습니다." });
    }
});
