-- 사용자 통계 테이블
CREATE TABLE user_stats (
    stats_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_analyses INT DEFAULT 0, -- 총 분석 횟수
    last_analysis_date DATE,
    favorite_analysis TEXT, -- 가장 선호하는 분석
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);
