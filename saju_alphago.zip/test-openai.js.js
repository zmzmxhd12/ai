const axios = require('axios');
const fs = require('fs');

// API 키 불러오기
const apiKey = JSON.parse(fs.readFileSync('./config/api-keys.json')).openai_api_key;

// OpenAI API 호출 함수
async function callOpenAI() {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo", // gpt-4 대신 gpt-3.5-turbo 사용
                messages: [
                    { role: "user", content: "What is the purpose of life?" }
                ],
                max_tokens: 50
            },
            {
                headers: {
                    Authorization: `Bearer ${apiKey}`
                }
            }
        );
        console.log("Response from OpenAI:", response.data.choices[0].message.content);
    } catch (error) {
        console.error("Error calling OpenAI API:", error.response ? error.response.data : error.message);
    }
}

// API 호출 실행
callOpenAI();
